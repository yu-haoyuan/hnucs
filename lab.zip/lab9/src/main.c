#include "prt_typedef.h"
#include "prt_tick.h"
#include "prt_task.h"
#include "prt_sem.h"
#include "prt_shell.h"

extern U32 PRT_Printf(const char *format, ...);
extern void PRT_UartInit(void);
extern U32 OsActivate(void);
extern U32 OsTskInit(void);
extern U32 OsSemInit(void);
extern U32 ShellTaskInit(ShellCB *shellCB);
extern U32 OsHwiInit(void);
static SemHandle sem_sync;
extern ShellCB g_shellCB;
extern void CoreTimerInit(void);
static SemHandle sem_sync;

S32 main(void)
{
    OsHwiInit();
    OsTskInit();
    OsSemInit(); 
    CoreTimerInit();
    PRT_UartInit();
    PRT_Printf("ctr-a h: print help of qemu emulator. ctr-a x: quit emulator.\n\n");
    ShellTaskInit(&g_shellCB);
    OsActivate();
    // while(1);
    return 0;

}
