#include "prt_typedef.h"
#include "os_exc_armv8.h"
#include"os_attr_armv8_external.h"
#include"os_cpu_armv8.h"

extern void OsTickDispatcher(void);
extern void OsUartRxHandle(void);
OS_SEC_ALW_INLINE INLINE void OsHwiHandleActive(U32 irqNum)
{
    switch(irqNum){
        case 30:
            OsTickDispatcher();
            // PRT_Printf(".");
            break;
        case 33:
            OsUartRxHandle();
        default:
            break;
    }
}

extern  U32 OsGicIntAcknowledge(void);
extern void OsGicIntClear(U32 value);
// src/arch/cpu/armv8/common/hwi/prt_hwi.c  OsHwiDispatch(),OsHwiDispatchHandle()
/*
* 鎻忚堪: 涓柇澶勭悊鍏ュ彛, 璋冪敤澶勫閮ㄥ凡鍏充腑鏂?
*/
OS_SEC_L0_TEXT void OsHwiDispatch( U32 excType, struct ExcRegInfo *excRegs) //src/arch/cpu/armv8/common/hwi/prt_hwi.c
{
    // 涓柇纭锛岀浉褰撲簬OsHwiNumGet()
    U32 value = OsGicIntAcknowledge();
    U32 irq_num = value & 0x1ff;
    U32 core_num = value & 0xe00;

    OsHwiHandleActive(irq_num);

    // 娓呴櫎涓柇锛岀浉褰撲簬 OsHwiClear(hwiNum);
    OsGicIntClear(irq_num|core_num);
}
extern U32 PRT_Printf(const char *format, ...);

// ExcRegInfo 鏍煎紡涓?OsExcDispatch 涓瘎瀛樺櫒瀛樺偍椤哄簭瀵瑰簲
void OsExcHandleEntry(U32 excType, struct ExcRegInfo *excRegs)
{
    PRT_Printf("Catch a exception.\n");
}

extern void TryPutc(unsigned char ch);
void MyFirstSyscall(char *str)
{
    while (*str != '\0') {
        TryPutc(*str);
        str++;
    }
}
// ExcRegInfo 鏍煎紡涓?OsExcDispatchFromLowEl 涓瘎瀛樺櫒瀛樺偍椤哄簭瀵瑰簲
void OsExcHandleFromLowElEntry(U32 excType, struct ExcRegInfo *excRegs)
{
    int ExcClass = (excRegs->esr&0xfc000000)>>26;
    if (ExcClass == 0x15){ //SVC instruction execution in AArch64 state.
        PRT_Printf("Catch a SVC call.\n");
        // syscall number瀛樺湪x8瀵勫瓨鍣ㄤ腑, x0涓哄弬鏁?
        int syscall_num = excRegs->xregs[(XREGS_NUM - 1)- 8]; //uniproton瀛樺偍鐨勯『搴弜0鍦ㄩ珮锛寈30鍦ㄤ綆
        uintptr_t param0 = excRegs->xregs[(XREGS_NUM - 1)- 0];
        PRT_Printf("syscall number: %d, param 0: 0x%x\n", syscall_num, param0);

        switch(syscall_num){
            case 1:
                MyFirstSyscall((void *)param0);
                break;
            default:
                PRT_Printf("Unimplemented syscall.\n");
        }
    }else{
        PRT_Printf("Catch a exception.\n");

    }
}
/*
* 鎻忚堪: 寮€鍚叏灞€鍙睆钄戒腑鏂€?
*/
OS_SEC_L0_TEXT uintptr_t PRT_HwiUnLock(void) //src/arch/cpu/armv8/common/hwi/prt_hwi.c
{
    uintptr_t state = 0;

    OS_EMBED_ASM(
        "mrs %0, DAIF      \n"
        "msr DAIFClr, %1   \n"
        : "=r"(state)
        : "i"(DAIF_IRQ_BIT)
        : "memory", "cc");

    return state & INT_MASK;
}

/*
* 鎻忚堪: 鍏抽棴鍏ㄥ眬鍙睆钄戒腑鏂€?
*/
OS_SEC_L0_TEXT uintptr_t PRT_HwiLock(void) //src/arch/cpu/armv8/common/hwi/prt_hwi.c
{
    uintptr_t state = 0;
    OS_EMBED_ASM(
        "mrs %0, DAIF      \n"
        "msr DAIFSet, %1   \n"
        : "=r"(state)
        : "i"(DAIF_IRQ_BIT)
        : "memory", "cc");
    return state & INT_MASK;
}

/*
* 鎻忚堪: 鎭㈠鍘熶腑鏂姸鎬佸瘎瀛樺櫒銆?
*/
OS_SEC_L0_TEXT void PRT_HwiRestore(uintptr_t intSave) //src/arch/cpu/armv8/common/hwi/prt_hwi.c
{
    if ((intSave & INT_MASK) == 0) {
        OS_EMBED_ASM(
            "msr DAIFClr, %0\n"
            :
            : "i"(DAIF_IRQ_BIT)
            : "memory", "cc");
    } else {
        OS_EMBED_ASM(
            "msr DAIFSet, %0\n"
            :
            : "i"(DAIF_IRQ_BIT)
            : "memory", "cc");
    }
    return;
}
