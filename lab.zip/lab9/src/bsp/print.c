#include <stdarg.h>
#include "prt_typedef.h"
#include "prt_sem.h"
#include "prt_shell.h"

#define UARTCR_UARTEN (1 << 0)
#define UARTCR_TXE (1 << 8)
#define UARTCR_RXE (1 << 9)

#define UARTICR_ALL (1 << 0)

#define UARTIMSC_RXIM (1 << 4)

#define UARTIBRD_IBRD_MASK 0xFFFF
#define UARTFBRD_FBRD_MASK 0x3F

#define UARTLCR_H_WLEN_MASK (3 << 5)
#define UARTLCR_H_PEN (1 << 1)
#define UARTLCR_H_STP1 (0 << 3)
#define UART_0_REG_BASE 0x09000000 // pl011 璁惧瀵勫瓨鍣ㄥ湴鍧€
// 瀵勫瓨鍣ㄥ強鍏朵綅瀹氫箟鍙傝锛歨ttps://developer.arm.com/documentation/ddi0183/g/programmers-model/summary-of-registers
#define DW_UART_THR 0x00 // UARTDR(Data Register) 瀵勫瓨鍣?
#define DW_UART_FR 0x18  // UARTFR(Flag Register) 瀵勫瓨鍣?
#define DW_UART_LCR_HR 0x2c  // UARTLCR_H(Line Control Register) 瀵勫瓨鍣?
#define DW_XFIFO_NOT_FULL 0x020  // 鍙戦€佺紦鍐插尯婊＄疆浣?
#define DW_FIFO_ENABLE 0x10 // 鍚敤鍙戦€佸拰鎺ユ敹FIFO

#define UART_BUSY_TIMEOUT   1000000
#define OS_MAX_SHOW_LEN 0x200


#define UART_REG_READ(addr)          (*(volatile U32 *)(((uintptr_t)addr)))  // 璇昏澶囧瘎瀛樺櫒
#define UART_REG_WRITE(value, addr)  (*(volatile U32 *)((uintptr_t)addr) = (U32)value) // 鍐欒澶囧瘎瀛樺櫒

SemHandle sem_uart_rx;

extern void OsGicIntSetConfig(uint32_t interrupt, uint32_t config);
extern void OsGicIntSetPriority(uint32_t interrupt, uint32_t priority);
extern void OsGicEnableInt(U32 intId);
extern void OsGicClearInt(uint32_t interrupt);
extern U32 PRT_Printf(const char *format, ...);

U32 PRT_UartInit(void)
{
    U32 result = 0;
    U32 reg_base = UART_0_REG_BASE;

    UART_REG_WRITE(0, (unsigned long)(reg_base + 0x30));// 绂佺敤pl011
    UART_REG_WRITE(0x7ff, (unsigned long)(reg_base + 0x44));// 娓呯┖涓柇鐘舵€?
    UART_REG_WRITE(UARTIMSC_RXIM, (unsigned long)(reg_base + 0x38));// 璁惧畾涓柇mask锛岄渶瑕佷娇鑳界殑涓柇
    UART_REG_WRITE(13, (unsigned long)(reg_base + 0x24));
    UART_REG_WRITE(1, (unsigned long)(reg_base + 0x28));

    // https://developer.arm.com/documentation/ddi0183/g/programmers-model/register-descriptions/line-control-register--uartlcr-h?lang=en
    result = UART_REG_READ((unsigned long)(reg_base + DW_UART_LCR_HR));
    result = result | UARTLCR_H_WLEN_MASK | UARTLCR_H_PEN | UARTLCR_H_STP1 | DW_FIFO_ENABLE;
    UART_REG_WRITE(result, (unsigned long)(reg_base + DW_UART_LCR_HR)); // 8N1 FIFO enable

    UART_REG_WRITE(UARTCR_UARTEN | UARTCR_RXE | UARTCR_TXE, (unsigned long)(reg_base + 0x30));// 鍚敤pl011


    // 鍚敤UART 鎺ユ敹涓柇
    OsGicIntSetConfig(33, 0); //鍙渷鐣?
    OsGicIntSetPriority(33, 0);
    OsGicClearInt(33); //鍙渷鐣?
    OsGicEnableInt(33);

    // 鍒涘缓uart鏁版嵁鎺ユ敹淇″彿閲?
    U32 ret;
    ret = PRT_SemCreate(0, &sem_uart_rx);
    if (ret != OS_OK) {
        PRT_Printf("failed to create uart_rx sem\n");
        return 1;
    }

    return OS_OK;
}

// 璇?reg_base + offset 瀵勫瓨鍣ㄧ殑鍊笺€?uartno 鍙傛暟鏈娇鐢?
S32 uart_reg_read(S32 uartno, U32 offset, U32 *val)
{
    S32 ret;
    U32 reg_base = UART_0_REG_BASE;


    *val = UART_REG_READ((unsigned long)(reg_base + offset));
    return OS_OK;
}

// 閫氳繃妫€鏌?FR 瀵勫瓨鍣ㄧ殑鏍囧織浣嶇‘瀹氬彂閫佺紦鍐叉槸鍚︽弧锛屾弧鏃惰繑鍥?.
S32 uart_is_txfifo_full(S32 uartno)
{
    S32 ret;
    U32 usr = 0;

    ret = uart_reg_read(uartno, DW_UART_FR, &usr);
    if (ret) {
        return OS_OK;
    }

    return (usr & DW_XFIFO_NOT_FULL);
}

// 寰€ reg_base + offset 瀵勫瓨鍣ㄤ腑鍐欏叆鍊?val銆?
void uart_reg_write(S32 uartno, U32 offset, U32 val)
{
    S32 ret;
    U32 reg_base = UART_0_REG_BASE;

    UART_REG_WRITE(val, (unsigned long)(reg_base + offset));
    return;
}

// 閫氳繃杞鐨勬柟寮忓彂閫佸瓧绗﹀埌涓插彛
void uart_poll_send(unsigned char ch)
{

    S32 timeout = 0;
    S32 max_timeout = UART_BUSY_TIMEOUT;

    // 杞鍙戦€佺紦鍐插尯鏄惁婊?
    int result = uart_is_txfifo_full(0);
    while (result) {
        timeout++;
        if (timeout >= max_timeout) {
            return;
        }
        result = uart_is_txfifo_full(0);
    }

    // 濡傛灉缂撳啿鍖烘病婊★紝閫氳繃寰€鏁版嵁瀵勫瓨鍣ㄥ啓鍏ユ暟鎹彂閫佸瓧绗﹀埌涓插彛
    uart_reg_write(0, DW_UART_THR, (U32)(U8)ch);
    return;
}

// 杞鐨勬柟寮忓彂閫佸瓧绗﹀埌涓插彛锛屼笖杞箟鎹㈣绗?
void TryPutc(unsigned char ch)
{
    uart_poll_send(ch);
    if (ch == '\n') {
        uart_poll_send('\r');
    }
}

extern int  vsnprintf_s(char *buff, int buff_size, int count, char const *fmt, va_list arg);
int TryPrintf(const char *format, va_list vaList)
{
    int len;
    char buff[OS_MAX_SHOW_LEN] = {0};
    char *str = buff;

    len = vsnprintf_s(buff, OS_MAX_SHOW_LEN, OS_MAX_SHOW_LEN, format, vaList);
    if (len == -1) {
        return len;
    }

    while (*str != '\0') {
        TryPutc(*str);
        str++;
    }

    return OS_OK;
}

U32 PRT_Printf(const char *format, ...)
{
    va_list vaList;
    S32 count;

    va_start(vaList, format);
    count = TryPrintf(format, vaList);
    va_end(vaList);

    return count;
}

ShellCB g_shellCB;
void OsUartRxHandle(void)
{
    U32 flag = 0;
    U32 result = 0;
    U32 reg_base = UART_0_REG_BASE;

    flag = UART_REG_READ((unsigned long)(reg_base + 0x18));
    while((flag & (1<<4)) == 0)
    {
        result = UART_REG_READ((unsigned long)(reg_base + 0x0));
        // PRT_Printf("%c", result);

        // 灏嗘敹鍒扮殑瀛楃瀛樺埌g_shellCB鐨勭紦鍐插尯
        g_shellCB.shellBuf[g_shellCB.shellBufOffset] = (char) result;
        g_shellCB.shellBufOffset++;
        if (g_shellCB.shellBufOffset == SHELL_SHOW_MAX_LEN)
            g_shellCB.shellBufOffset = 0;

        PRT_SemPost(sem_uart_rx);
        flag = UART_REG_READ((unsigned long)(reg_base + 0x18));
    }
    return;
}
