#include "prt_task_external.h"
#include "prt_typedef.h"
#include "os_attr_armv8_external.h"
#include "prt_asm_cpu_external.h"
#include "os_cpu_armv8_external.h"
#include "prt_amp_task_internal.h"

OS_SEC_BSS struct TagOsRunQue g_runQueue;  // 鏍哥殑灞€閮ㄨ繍琛岄槦鍒?

/*
* 鎻忚堪锛氬皢浠诲姟娣诲姞鍒板氨缁槦鍒? 璋冪敤鑰呯‘淇濅笉浼氭崲鏍革紝骞堕攣涓妑q
*/
OS_SEC_L0_TEXT void OsTskReadyAdd(struct TagTskCb *task)
{
    struct TagOsRunQue *rq = &g_runQueue;
    TSK_STATUS_SET(task, OS_TSK_READY);

    OS_TSK_EN_QUE(rq, task, 0);
    OsTskHighestSet();

    return;
}

/*
* 鎻忚堪锛氬皢浠诲姟浠庡氨缁槦鍒椾腑绉婚櫎锛屽叧涓柇澶栭儴淇濊瘉
*/
OS_SEC_L0_TEXT void OsTskReadyDel(struct TagTskCb *taskCb)
{
    struct TagOsRunQue *runQue = &g_runQueue;
    TSK_STATUS_CLEAR(taskCb, OS_TSK_READY);

    OS_TSK_DE_QUE(runQue, taskCb, 0);
    OsTskHighestSet();

    return;
}

// src/core/kernel/task/prt_task_del.c
/*
* 鎻忚堪锛氫换鍔＄粨鏉熼€€鍑?
*/
OS_SEC_L4_TEXT void OsTaskExit(struct TagTskCb *tsk)
{

    uintptr_t intSave = OsIntLock();

    OsTskReadyDel(tsk);
    OsTskSchedule();

    OsIntRestore(intSave);

}

// src/core/kernel/task/prt_amp_task.c
/*
* 鎻忚堪锛氬鏋滃揩閫熷垏鎹㈠悗鍙湁涓柇鎭㈠锛屼娇鐢ㄦ鎺ュ彛
*/
OS_SEC_TEXT void OsTskScheduleFastPs(uintptr_t intSave)
{
    /* Find the highest task */
    OsTskHighestSet();

    /* In case that running is not highest then reschedule */
    if ((g_highestTask != RUNNING_TASK) && (g_uniTaskLock == 0)) {
        UNI_FLAG |= OS_FLG_TSK_REQ;

        /* only if there is not HWI or TICK the trap */
        if (OS_INT_INACTIVE) {
            OsTaskTrapFastPs(intSave);
        }
    }
}
extern U32 PRT_Printf(const char *format, ...);
OS_SEC_TEXT void OsDisplayTasksInfo(void)
{
    struct TagTskCb *taskCb = NULL;
    U32 cnt = 0;

    PRT_Printf("\nPID\t\tPriority\tStack Size\n");
    // 閬嶅巻g_runQueue闃熷垪锛屾煡鎵句紭鍏堢骇鏈€楂樼殑浠诲姟
    LIST_FOR_EACH(taskCb, &g_runQueue, struct TagTskCb, pendList) {
        cnt++;
        PRT_Printf("%d\t\t%d\t\t%d\n", taskCb->taskPid, taskCb->priority, taskCb->stackSize);
    }
    PRT_Printf("Total %d tasks", cnt);

}
