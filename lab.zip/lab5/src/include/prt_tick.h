#ifndef PRT_TICK_H
#define PRT_TICK_H

#include "prt_typedef.h"

extern U64 PRT_TickGetCount(void);

#endif /* PRT_TICK_H */
